package com.example.inventoryapp

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.switchMap
import androidx.lifecycle.viewModelScope
import androidx.room.*
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import java.util.Locale

// =========================================================
// 1. قاعدة البيانات المحلية (Room Entity, DAO, Database)
// =========================================================

@Entity(tableName = "inventory_items")
data class InventoryItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val quantity: Int,
    val price: Double,
    val barcode: String? = null
)

@Dao
interface InventoryDao {
    @Query("SELECT * FROM inventory_items ORDER BY id DESC")
    fun getAllItems(): Flow<List<InventoryItem>>

    @Query("SELECT * FROM inventory_items WHERE name LIKE '%' || :query || '%' OR barcode LIKE '%' || :query || '%' ORDER BY id DESC")
    fun searchItems(query: String): Flow<List<InventoryItem>>

    @Query("SELECT * FROM inventory_items WHERE LOWER(name) = LOWER(:name) LIMIT 1")
    suspend fun getItemByName(name: String): InventoryItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: InventoryItem): Long

    @Update
    suspend fun updateItem(item: InventoryItem)

    @Delete
    suspend fun deleteItem(item: InventoryItem)
}

@Database(entities = [InventoryItem::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun inventoryDao(): InventoryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: android.content.Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "single_inventory_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

// =========================================================
// 2. إدارة البيانات والمنطق (ViewModel)
// =========================================================

class InventoryViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AppDatabase.getDatabase(application).inventoryDao()
    private val searchQuery = MutableLiveData("")

    val itemsList: LiveData<List<InventoryItem>> = searchQuery.switchMap { query ->
        if (query.isNullOrBlank()) {
            dao.getAllItems().asLiveData()
        } else {
            dao.searchItems(query).asLiveData()
        }
    }

    fun setSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun insertItem(item: InventoryItem) = viewModelScope.launch {
        dao.insertItem(item)
    }

    fun updateItem(item: InventoryItem) = viewModelScope.launch {
        dao.updateItem(item)
    }

    fun deleteItem(item: InventoryItem) = viewModelScope.launch {
        dao.deleteItem(item)
    }

    fun incrementQuantity(item: InventoryItem) = viewModelScope.launch {
        dao.updateItem(item.copy(quantity = item.quantity + 1))
    }

    fun decrementQuantity(item: InventoryItem) = viewModelScope.launch {
        if (item.quantity > 0) {
            dao.updateItem(item.copy(quantity = item.quantity - 1))
        }
    }

    suspend fun getItemByName(name: String): InventoryItem? {
        return dao.getItemByName(name)
    }
}

// =========================================================
// 3. النشاط الرئيسي وواجهات المستخدم (MainActivity & UI)
// =========================================================

class MainActivity : ComponentActivity() {
    private val viewModel: InventoryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // فرض الاتجاه من اليمين إلى اليسار (RTL) للغة العربية
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme {
                    InventoryAppScreen(viewModel)
                }
            }
        }
    }
}

@Composable
fun InventoryAppScreen(viewModel: InventoryViewModel) {
    val items by viewModel.itemsList.observeAsState(initial = emptyList())
    var searchText by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()

    var showAddDialog by remember { mutableStateOf(false) }
    var itemToEdit by remember { mutableStateOf<InventoryItem?>(null) }
    var itemToDelete by remember { mutableStateOf<InventoryItem?>(null) }
    var duplicatePrompt by remember { mutableStateOf<Pair<InventoryItem, InventoryItem>?>(null) }

    // ماسح الباركود للبحث
    val searchScanLauncher = rememberLauncherForActivityResult(contract = ScanContract()) { result ->
        if (result.contents != null) {
            searchText = result.contents
            viewModel.setSearchQuery(result.contents)
        }
    }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(16.dp)
            ) {
                Text(
                    text = "جرد المخزون",
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(12.dp))

                // بطاقة إحصائيات المخزون
                StatsHeader(items = items)

                Spacer(modifier = Modifier.height(12.dp))

                // شريط البحث المباشر
                OutlinedTextField(
                    value = searchText,
                    onValueChange = {
                        searchText = it
                        viewModel.setSearchQuery(it)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("ابحث عن صنف...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        IconButton(onClick = {
                            val options = ScanOptions().apply {
                                setDesiredBarcodeFormats(ScanOptions.ALL_CODE_TYPES)
                                setPrompt("وجه الكاميرا نحو الباركود")
                                setBeepEnabled(true)
                                setOrientationLocked(false)
                            }
                            searchScanLauncher.launch(options)
                        }) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = "مسح باركود", tint = MaterialTheme.colorScheme.primary)
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    itemToEdit = null
                    showAddDialog = true
                },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("إضافة صنف", fontWeight = FontWeight.Bold) },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFF5F7FA))
        ) {
            if (items.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = if (searchText.isEmpty()) "لا توجد أصناف في المخزون" else "لا توجد أصناف مطابقة للبحث",
                        color = Color.Gray,
                        fontSize = 16.sp
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(items, key = { it.id }) { item ->
                        InventoryItemCard(
                            item = item,
                            onPlus = { viewModel.incrementQuantity(item) },
                            onMinus = { viewModel.decrementQuantity(item) },
                            onEdit = {
                                itemToEdit = item
                                showAddDialog = true
                            },
                            onDelete = { itemToDelete = item }
                        )
                    }
                }
            }
        }
    }

    // نافذة إضافة / تعديل صنف
    if (showAddDialog) {
        AddEditItemDialog(
            item = itemToEdit,
            onDismiss = { showAddDialog = false },
            onSave = { name, qty, price, barcode ->
                coroutineScope.launch {
                    if (itemToEdit != null) {
                        viewModel.updateItem(itemToEdit!!.copy(name = name, quantity = qty, price = price, barcode = barcode))
                        showAddDialog = false
                    } else {
                        val existing = viewModel.getItemByName(name)
                        if (existing != null) {
                            duplicatePrompt = Pair(existing, InventoryItem(name = name, quantity = qty, price = price, barcode = barcode))
                            showAddDialog = false
                        } else {
                            viewModel.insertItem(InventoryItem(name = name, quantity = qty, price = price, barcode = barcode))
                            showAddDialog = false
                        }
                    }
                }
            }
        )
    }

    // نافذة التأكد في حالة وجود صنف مكرر
    if (duplicatePrompt != null) {
        val (existing, pending) = duplicatePrompt!!
        AlertDialog(
            onDismissRequest = { duplicatePrompt = null },
            title = { Text("صنف موجود بالفعل", fontWeight = FontWeight.Bold) },
            text = { Text("يوجد صنف باسم \"${existing.name}\" بالفعل. هل تريد إضافة الكمية المدخلة (${pending.quantity}) إلى الكمية الحالية (${existing.quantity})؟") },
            confirmButton = {
                Button(onClick = {
                    viewModel.updateItem(existing.copy(
                        quantity = existing.quantity + pending.quantity,
                        price = pending.price,
                        barcode = pending.barcode ?: existing.barcode
                    ))
                    duplicatePrompt = null
                }) {
                    Text("إضافة الكمية", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { duplicatePrompt = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // نافذة تأكيد الحذف
    if (itemToDelete != null) {
        AlertDialog(
            onDismissRequest = { itemToDelete = null },
            title = { Text("تأكيد الحذف", fontWeight = FontWeight.Bold) },
            text = { Text("هل أنت متأكد أنك تريد حذف الصنف \"${itemToDelete?.name}\"؟") },
            confirmButton = {
                Button(
                    onClick = {
                        itemToDelete?.let { viewModel.deleteItem(it) }
                        itemToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                ) {
                    Text("حذف", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { itemToDelete = null }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
fun StatsHeader(items: List<InventoryItem>) {
    val totalCount = items.size
    val totalQty = items.sumOf { it.quantity }
    val totalValue = items.sumOf { it.quantity * it.price }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatColumn(title = "إجمالي الأصناف", value = "$totalCount", color = MaterialTheme.colorScheme.primary)
            Divider(modifier = Modifier.height(32.dp).width(1.dp), color = Color.LightGray)
            StatColumn(title = "إجمالي الكمية", value = "$totalQty", color = Color(0xFF43A047))
            Divider(modifier = Modifier.height(32.dp).width(1.dp), color = Color.LightGray)
            StatColumn(title = "إجمالي القيمة", value = String.format(Locale.getDefault(), "%.2f", totalValue), color = Color(0xFF212121))
        }
    }
}

@Composable
fun StatColumn(title: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = color)
        Text(text = title, fontSize = 11.sp, color = Color.Gray)
    }
}

@Composable
fun InventoryItemCard(
    item: InventoryItem,
    onPlus: () -> Unit,
    onMinus: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = item.name,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF212121)
                )

                Row {
                    IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red)
                    }
                }
            }

            if (!item.barcode.isNullOrEmpty()) {
                Text(
                    text = "باركود: ${item.barcode}",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = Color(0xFFE0E0E0))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = String.format(Locale.getDefault(), "السعر: %.2f", item.price),
                        fontSize = 13.sp,
                        color = Color.DarkGray
                    )
                    Text(
                        text = String.format(Locale.getDefault(), "الإجمالي: %.2f", item.quantity * item.price),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2E7D32)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(
                        onClick = onMinus,
                        modifier = Modifier.size(36.dp),
                        contentPadding = PaddingValues(0.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("−", fontSize = 18.sp, color = Color.Red, fontWeight = FontWeight.Bold)
                    }

                    Text(
                        text = "${item.quantity}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )

                    OutlinedButton(
                        onClick = onPlus,
                        modifier = Modifier.size(36.dp),
                        contentPadding = PaddingValues(0.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("+", fontSize = 18.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AddEditItemDialog(
    item: InventoryItem?,
    onDismiss: () -> Unit,
    onSave: (name: String, qty: Int, price: Double, barcode: String?) -> Unit
) {
    var name by remember { mutableStateOf(item?.name ?: "") }
    var qtyText by remember { mutableStateOf(item?.quantity?.toString() ?: "1") }
    var priceText by remember { mutableStateOf(item?.price?.toString() ?: "0.0") }
    var barcodeText by remember { mutableStateOf(item?.barcode ?: "") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val dialogScanLauncher = rememberLauncherForActivityResult(contract = ScanContract()) { result ->
        if (result.contents != null) {
            barcodeText = result.contents
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = if (item == null) "إضافة صنف جديد" else "تعديل الصنف",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF212121)
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        errorMessage = null
                    },
                    label = { Text("اسم الصنف") },
                    isError = errorMessage != null,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                if (errorMessage != null) {
                    Text(text = errorMessage!!, color = Color.Red, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = qtyText,
                    onValueChange = { qtyText = it },
                    label = { Text("الكمية") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("سعر الوحدة") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = barcodeText,
                        onValueChange = { barcodeText = it },
                        label = { Text("الباركود (اختياري)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    OutlinedButton(
                        onClick = {
                            val options = ScanOptions().apply {
                                setDesiredBarcodeFormats(ScanOptions.ALL_CODE_TYPES)
                                setPrompt("وجه الكاميرا نحو الباركود")
                                setBeepEnabled(true)
                                setOrientationLocked(false)
                            }
                            dialogScanLauncher.launch(options)
                        },
                        modifier = Modifier.height(56.dp)
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("إلغاء")
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            val trimmedName = name.trim()
                            if (trimmedName.isEmpty()) {
                                errorMessage = "يرجى إدخال اسم الصنف"
                                return@Button
                            }
                            val qty = qtyText.toIntOrNull() ?: 0
                            val price = priceText.toDoubleOrNull() ?: 0.0

                            onSave(trimmedName, qty.coerceAtLeast(0), price.coerceAtLeast(0.0), barcodeText.trim().ifEmpty { null })
                        }
                    ) {
                        Text(if (item == null) "حفظ" else "حفظ التعديلات")
                    }
                }
            }
        }
    }
}